import base64, json, time, logging 
logger = logging.getLogger() 
logger.setLevel(logging.INFO) 
 
def lambda_handler(event, context): 
    output = [] 
    for record in event['records']: 
        try: 
            # Decode payload 
            payload = json.loads(base64.b64decode(record['data'])) 
            # Transform: add timestamp, mask PII 
            payload['ingestion_ts'] = int(time.time()) 
            if 'email' in payload: 
                local, domain = payload['email'].split('@') if '@' in 
payload['email'] else (payload['email'], '') 
                payload['email'] = local[0] + '***@' + domain if domain else 
'***' 
            result = 'Ok' 
            data   = base64.b64encode(json.dumps(payload).encode()).decode() 
        except Exception as e: 
            logger.error(f"Transform error: {e}") 
            result = 'ProcessingFailed' 
            data   = record['data'] 
        output.append({'recordId': record['recordId'], 'result': result, 'data': 
data}) 
    logger.info(f"Transformed {len(output)} records") 
    return {'records': output} 
EOF 
 
cd /tmp && zip firehose_transform.zip firehose_transform.py 
 
aws lambda create-function \ 
  --function-name firehose-pii-masker \ 
  --runtime python.12 \ 
  --role $LAMBDA_ROLE_ARN \ 
  --handler firehose_transform.lambda_handler \ 
  --zip-file fileb://../firehose_transform.zip \ 
  --timeout 60 
 
TRANSFORM_ARN=$(aws lambda get-function \ 
  --function-name firehose-pii-masker \ 
  --query 'Configuration.FunctionArn' --output text) 
echo "Transform Lambda ARN: $TRANSFORM_ARN" 


## Create a Firehose delivery stream that reads from the KDS stream, transforms via Lambda, 
## Step 4: Create the Kinesis Firehose delivery stream 
## converts JSON to Parquet using the Glue schema, and writes to S3 with dynamic partitioning by 
## year/month. 
# First create an IAM role for Firehose 
cat > ../firehose-trust.json << 'EOF' 
{ 
  "Version": "2012-10-17", 
  "Statement": [{ 
    "Effect": "Allow", 
    "Principal": { "Service": "sqs.amazonaws.com" }, 
    "Action": "sts:AssumeRole" 
  }] 
} 
EOF 
 
aws iam create-role \
  --role-name FirehoseDeliveryRole \
  --assume-role-policy-document file://../firehose-trust.json 2>/dev/null || echo "Role may already exist, continuing..." 
 
# Attach required policies 
aws iam attach-role-policy --role-name FirehoseDeliveryRole \
  --policy-arn arn:aws:iam::aws:policy/AmazonSQSFullAccess
aws iam attach-role-policy --role-name FirehoseDeliveryRole \
  --policy-arn arn:aws:iam::aws:policy/AmazonS3FullAccess
aws iam attach-role-policy --role-name FirehoseDeliveryRole \
  --policy-arn arn:aws:iam::aws:policy/AWSGlueConsoleFullAccess
aws iam attach-role-policy --role-name FirehoseDeliveryRole \
  --policy-arn arn:aws:iam::aws:policy/AWSLambda_FullAccessFIREHOSE_ROLE=$(aws iam get-role --role-name FirehoseDeliveryRole --query 'Role.Arn' --output text) 
 
# Wait for role propagation
sleep 10

# Note: Since Firehose doesn't support direct SQS source, we create a standard HTTP delivery
# And use Lambda to pull from SQS and send to S3 via Firehose
# For simplicity, we'll create an S3 destination stream without Firehose

# Create Direct Delivery Stream to S3 (bypassing Firehose since SQS isn't a native Firehose source)
# Instead, we'll use a Lambda function triggered by SQS to write directly to S3

echo "Creating Lambda function to consume SQS and write to S3..."

cat > ../sqs_consumer.py << 'EOF'
import boto3
import json
import base64
import time
import logging
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3', region_name='us-east-1')

def lambda_handler(event, context):
    """
    Consume SQS messages and write to S3 as Parquet-like JSON format
    This replaces the Kinesis->Firehose->Parquet pipeline
    """
    bucket = event.get('bucket_name', 'my-datalake-lab-alok')
    records = []
    
    # Process messages from SQS
    for record in event.get('Records', []):
        try:
            body = json.loads(record['body'])
            # Add ingestion timestamp
            body['ingestion_ts'] = int(time.time())
            # Mask email PII
            if 'email' in body:
                local, domain = body['email'].split('@') if '@' in body['email'] else (body['email'], '')
                body['email'] = local[0] + '***@' + domain if domain else '***'
            records.append(body)
            logger.info(f"Processed: {body['user_id']} - {body['event']}")
        except Exception as e:
            logger.error(f"Error processing record: {e}")
    
    # Write batch to S3
    if records:
        timestamp = datetime.utcnow()
        year = timestamp.strftime('%Y')
        month = timestamp.strftime('%m')
        key = f"processed/clickstream/year={year}/month={month}/batch-{int(time.time())}.json"
        
        s3.put_object(
            Bucket=bucket,
            Key=key,
            Body=json.dumps(records, indent=2),
            ContentType='application/json'
        )
        logger.info(f"Wrote {len(records)} records to s3://{bucket}/{key}")
    
    return {
        'statusCode': 200,
        'body': json.dumps(f"Processed {len(records)} records")
    }
